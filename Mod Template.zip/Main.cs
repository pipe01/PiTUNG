﻿using PiTung;
using System;

namespace $safeprojectname$
{
    public class $safeprojectname$ : Mod
    {
        public override string Name => "";
        public override string PackageName => "";
        public override string Author => "";
        public override Version ModVersion => new Version("1.0.0");
    }
}
